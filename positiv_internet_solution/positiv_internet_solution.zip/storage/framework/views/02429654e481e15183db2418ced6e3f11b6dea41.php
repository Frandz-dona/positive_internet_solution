<?php $__env->startSection('title'); ?>
Positive Internet Solution | Ajout Livre
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="wrapper">
    <main role="main" class="main-content">
        <div class="col-md-12">
            <div class="card shadow mb-4">
              <div class="card-header">
                <strong class="card-title">Création Livre</strong>
              </div>
              <div class="card-body">


                <form class="needs-validation" novalidate  method="POST" class="forms-sample" action=" <?php echo e(route('admin.store_livre')); ?> " id='addlivre' enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                  <div class="form-row">
                    <div class="col-md-6 mb-3">
                      <label for="validationCustom3">Nom</label>
                      <input id="nom" type="text" class="form-control <?php $__errorArgs = ['livre_nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="livre_nom" value="<?php echo e(old('livre_nom')); ?>" required autocomplete="livre_nom" autofocus placeholder="nom du livre">
                      <div class="valid-feedback"> valide </div>
                    </div>
                    <div class="col-md-6 mb-3">
                      <label for="validationCustom4">Auteur</label>
                      <input id="auteur" type="text" class="form-control <?php $__errorArgs = ['auteur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="auteur" value="<?php echo e(old('auteur')); ?>" required autocomplete="auteur" autofocus placeholder="auteur">
                      <div class="valid-feedback"> valide! </div>
                    </div>
                  </div> <!-- /.form-row -->
                  <div class="form-row">
                    <div class="col-md-3 mb-3">
                        <label for="exampl">Nombre de Page</label>
                        <input id="nbp" type="number" class="form-control <?php $__errorArgs = ['nbp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nbp" value="<?php echo e(old('nbp')); ?>" required autocomplete="nbp" autofocus placeholder="nombre de page">
                        <div class="valid-feedback"> valide! </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                      <label for="example-time">Prix Numerique</label>
                      <input id="prix_numerique" type="float" class="form-control <?php $__errorArgs = ['prix_numerique'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="prix_numerique" value="<?php echo e(old('prix_numerique')); ?>" autocomplete="prix_numerique" autofocus placeholder="prix_numerique">
                      <div class="valid-feedback"> valide! </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="example-time">Prix Papier</label>
                        <input id="prix_papier" type="float" class="form-control <?php $__errorArgs = ['prix_papier'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="prix_papier" value="<?php echo e(old('prix_papier')); ?>" autocomplete="prix_papier" autofocus placeholder="prix_papier">
                        <div class="valid-feedback"> valide! </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="example-time">Prix Promo</label>
                        <input id="prix_promo" type="float" class="form-control <?php $__errorArgs = ['prix_promo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="prix_promo" value="<?php echo e(old('prix_promo')); ?>"  autocomplete="prix_promo" autofocus placeholder="prix_promo">
                        <div class="valid-feedback"> valide! </div>
                      </div>
                  </div>
                  <div class="form-row mb-3">
                    <div class="col-md-3 mb-3">
                      <label for="date-input1">Date de Sortie</label>
                      <div class="input-group">
                        <input type="date" class="form-control" id="date-sortie" aria-describedby="button-addon2" name="date_sortie">
                        <div class="input-group-append">
                          <div class="input-group-text" id="button-addon-date"><span class="fe fe-calendar fe-16 mx-2"></span></div>
                        </div>
                      </div>
                    </div>


                    <div class="form-group mb-3">
                        <label for="customFile">Image</label>
                        <div class="custom-file">
                          <input id="image_principale" type="file" class="custom-file-input <?php $__errorArgs = ['image_principale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image_principale" autocomplete="image_principale" autofocus placeholder="image_principale">
                          <label class="custom-file-label" for="customFile">Choose file</label>
                        </div>
                    </div>
                      <div class="form-group mb-3">
                        <label for="customFile">Fichier</label>
                        <div class="custom-file">
                          <input id="fichier" type="file" class="custom-file-input <?php $__errorArgs = ['image_principale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="fichier_livre" autocomplete="fichier_livre" autofocus placeholder="fichier_livre">
                          <label class="custom-file-label" for="customFile">Choose file</label>
                        </div>
                      </div>
                  </div>

                  <div class="form-group mb-3">
                    <label for="validationTextarea1">description</label>
                    <textarea class="form-control" placeholder="Take a note here" required="" rows="3" id="validationTextarea1" type="text" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" value="<?php echo e(old('description')); ?>" required autocomplete="description" autofocus placeholder="description" ></textarea>
                    <div class="invalid-feedback"> Please enter a message in the textarea. </div>
                  </div>

                  

                  <button class="btn btn-primary" type="submit">Validez</button>
                </form>
              </div> <!-- /.card-body -->
            </div> <!-- /.card -->
          </div>

    </main> <!-- main -->
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startPush('livre'); ?>

<script>
    toastr.options.preventDuplicates = true;
        $.ajaxSetup({
            headers:{
                'X-CSRF-TOKEN':$('meta[name="crfs-token"]').attr('content')
            }
        });
        $(function(){
            //add livre
            $("#addlivre").on('submit', function(e){
                e.preventDefault();
                var form=this;

                $.ajax({
                    url:$(form).attr('action'),
                    method:$(form).attr('method'),
                    data:new FormData(form),
                    processData:false,
                    contentType:false,
                    dataType:'json',
                    beforeSend:function(){
                        $(form).find('span.error-text').text('');
                    },
                    success:function(data){
                        if(data.code ==0){
                            $.each(data.error, function(prefix, val){
                                $(form).find('span.'+prefix+'_error').text(val[0]);
                            });
                        }else{
                            $(form)[0].reset();
                            // $('#datatable').DataTable().ajax.reload(null, false);
                            location.reload();
                            toastr.success(data.msg);
                        }
                    }

                });

            });


        });



</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts/admin.ap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TONOU Frandz\Desktop\MES_PROJETS\pis\positiv_internet_solution\resources\views/interface_admin/livre/ajout.blade.php ENDPATH**/ ?>
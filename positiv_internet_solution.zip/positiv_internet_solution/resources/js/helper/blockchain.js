export default {

    // 
    path: 'https://api.blockchain.com/v3/exchange/',
    absolute: 'https://api.blockchain.com/v3/',

    getToken () {
        return '4758eadc-ba3d-4f30-8007-8bbcab10f459'
    },

}